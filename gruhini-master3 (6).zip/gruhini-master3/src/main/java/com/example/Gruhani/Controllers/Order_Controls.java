package com.example.Gruhani.Controllers;

import com.example.Gruhani.Repositories.OrderRepo;
import com.example.Gruhani.Repositories.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/orders")
@CrossOrigin(origins = "*")
public class Order_Controls {

    @Autowired
    private OrderRepo orderRepo;

    @Autowired
    private UserRepo userRepo;

    /**
     * POST /orders/create
     * Create a new order (PENDING state, pre-payment)
     */
    @PostMapping("/create")
    public ResponseEntity<?> createOrder(
            @RequestBody Map<String, Object> payload,
            Authentication authentication) {
        try {
            // Extract delivery info
            Map<String, String> delivery = (Map<String, String>) payload.get("deliveryAddress");
            Double total = ((Number) payload.get("total")).doubleValue();
            List<Map<String, Object>> cartItems = (List<Map<String, Object>>) payload.get("cartItems");

            // Create order response with Razorpay order ID
            Map<String, Object> response = new HashMap<>();
            String razorpayOrderId = "order_" + System.currentTimeMillis();
            
            response.put("orderId", 5001); // Sample - would be from DB
            response.put("razorpayOrderId", razorpayOrderId);
            response.put("status", "PENDING");
            response.put("message", "Order created. Proceed to payment.");

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(new HashMap<String, String>() {{
                put("error", "Order creation failed: " + e.getMessage());
            }});
        }
    }

    /**
     * GET /orders/{orderId}
     * Get order details
     */
    @GetMapping("/{orderId}")
    public ResponseEntity<?> getOrder(@PathVariable Long orderId, Authentication authentication) {
        try {
            // Build response with sample order
            Map<String, Object> response = new HashMap<>();
            response.put("id", orderId);
            response.put("status", "CONFIRMED");
            response.put("total", 599);
            response.put("deliveryAddress", "123 Main St, Mumbai, 400001");
            response.put("deliveryName", "Amit Kumar");
            response.put("deliveryPhone", "+91-9876543210");
            response.put("estimatedDelivery", LocalDateTime.now().plusMinutes(45));
            response.put("createdAt", LocalDateTime.now());
            
            // Add sample items
            List<Map<String, Object>> items = new ArrayList<>();
            Map<String, Object> item1 = new HashMap<>();
            item1.put("id", 1);
            item1.put("name", "Biryani");
            item1.put("quantity", 2);
            item1.put("price", 250);
            items.add(item1);
            
            response.put("items", items);
            response.put("seller", new HashMap<String, String>() {{
                put("id", "100");
                put("businessName", "Chef Manju");
            }});

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(new HashMap<String, String>() {{
                put("error", "Error fetching order: " + e.getMessage());
            }});
        }
    }

    /**
     * POST /orders/{orderId}/whatsapp-preference
     * Update WhatsApp notification preference
     */
    @PostMapping("/{orderId}/whatsapp-preference")
    public ResponseEntity<?> updateWhatsAppPreference(
            @PathVariable Long orderId,
            @RequestBody Map<String, Boolean> request) {
        try {
            Boolean optIn = request.get("optIn");

            return ResponseEntity.ok(new HashMap<String, String>() {{
                put("message", "WhatsApp preference updated to: " + optIn);
            }});

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(new HashMap<String, String>() {{
                put("error", "Error updating preference: " + e.getMessage());
            }});
        }
    }

    /**
     * PUT /orders/{orderId}/status
     * Update order status (for seller/admin)
     */
    @PutMapping("/{orderId}/status")
    public ResponseEntity<?> updateOrderStatus(
            @PathVariable Long orderId,
            @RequestBody Map<String, String> request,
            Authentication authentication) {
        try {
            String newStatus = request.get("status");

            Map<String, Object> response = new HashMap<>();
            response.put("message", "Order status updated to " + newStatus);
            response.put("orderId", orderId);
            response.put("status", newStatus);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(new HashMap<String, String>() {{
                put("error", "Error updating order status: " + e.getMessage());
            }});
        }
    }
}
